
const A187 = '『Space Trixx Bot』';
const gram = 'http://bit.ly/spaceTrixx';
const nomer = 'Wa.me/+5591985012862';
const aktif = 'Tergantung kuota'; 
const groupwhatsapp = 'https://youtu.be/w4ggQz5KMPY'; 
const youtube = 'http://bit.ly/3m7ZT3C';
const host = '185.88.181.7';


const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");

const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
//////// arquivos ////////
const dl = require("./lib/downloadImage.js");
const lobby = require("./lib/lobby.js");
const edu = require("./lib/edu.js");
const lista = require("./lib/lista.js");
////////////////////////////



const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   waChatKey,
} = require("@adiwajshing/Baileys");
var jam = moment().format("HH:mm");



function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃•••⟩ ${moment().format("HH:mm:ss")}
┃👁️           FAZ O SCAN CARALHO!
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);
});

conn.on('credentials-updated', () =>
{
   // salvar credenciais sempre que atualizado
   console.log(`               Crendenciais salvando...`)
   const authInfo = conn.base64EncodedAuthInfo() // obter todas as informações de autenticação de que precisamos para restaurar esta sessão
   
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // salve esta informação em um arquivo
   
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// descomente a linha a seguir para fazer o proxy da conexão; algum proxy aleatório que tirei: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();



//--------------⟩ Mensagens
conn.on('message-status-update', json =>
{
   let participant = json.participant;
   console.log(`┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃•••⟩ ${moment().format("HH:mm:ss")}
┃👤 ${participant} = Usuário
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`) })

conn.on('message-new', async(m) =>
{
   const messageContent = m.message
   const text = m.message.conversation
   let id = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // a mensagem sempre conterá uma chave que significa que tipo de mensagem
   let imageMessage = m.message.imageMessage;
   console.log(`┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃•••⟩ ${moment().format("HH:mm:ss")}
┃👥 ${id.split("@s.whatsapp.net")[0]}
┃📩 ${text} | ${messageType}
┃📍 ${imageMessage}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`);


///////////////////// YOUTUBE /////////////////////

if (text.includes('!yt')){
  var teks = text.replace(/!yt /, '')
    axios.get(`https://alfians-api.herokuapp.com/api/ytv?url=${teks}`).then((res) => {
      imageToBase64(res.data.thumb)
        .then(
          (ress) => {
          	var buf = Buffer.from(ress, 'base64')
          	
    let hasil = `•|🔎 Título: *${res.data.title}*\n•|🎦 Informação: *${res.data.resolution} | ${res.data.filesize} | ${res.data.ext}*\n•|📥 Download: *${res.data.result}*`;
    conn.sendMessage(id, '🔎 Buscando Link Download...', MessageType.text, { quoted: m })

            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })

        })

    })

}


///////////////////// INSTAGRAM /////////////////////

if (text.includes("!insta")){ 
  const teks = text.replace(/!insta /, "")
  axios.get(`https://alfians-api.herokuapp.com/api/stalk?username=${teks}`).then ((res) =>{
  	imageToBase64(res.data.Profile_pic)
        .then(
          (ress) => {
          	
          	var buf = Buffer.from(ress, 'base64')

  	conn.sendMessage(id, '*Se caso deu erro na pesquisa, tente novamente.*', MessageType.text, { quoted: m })
  
  conn.sendMessage(id, '🔎Espere! Estou trazendo informação do seu Instagram...', MessageType.text, { quoted: m })
  
  let hasil = `•|⭐ Seu Instagram está aqui *${teks}*

•|⭐ Instagram: *${res.data.Username}*
•|👤 Nome: *${res.data.Name}*
•|✍️ Bio: *${res.data.Biodata}*
•|📈Quantos Seguidores: *${res.data.Jumlah_Followers}*
•|📉 Quantos Seguindo: *${res.data.Jumlah_Following}*
•|📊 Quantas Postagem: *${res.data.Jumlah_Post}*`;
  conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
  })
  })
}

///////////////////// INFOR FILME /////////////////////

if (text.includes("!filme")){
const teks = text.replace(/!filme /, "")
axios.get(`https://arugaz.herokuapp.com/api/dewabatch?q=${teks}`).then((res) => {
	imageToBase64(res.data.thumb)
        .then(
          (ress) => {
          	
          	var buf = Buffer.from(ress, 'base64')
	conn.sendMessage(id, '💬Hm... Calma Aí!', MessageType.text, { quoted: m })
	
    let hasil = `•|🔎 Você Pesquisou: ${teks}\n•|🎦 Resultado:\n${res.data.result}`;
    conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
})
})
}

///////////////////// COMANDOS /////////////////////

if (text == '!cm'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, lobby.lobby(id, A187, corohelp, tampilTanggal, tampilWaktu, gram, nomer, aktif, groupwhatsapp, youtube, host) ,MessageType.text);
}

//////////////////////////////////////////////////////////////

if (text == '!script'){
	const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, edu.edu(id, A187, corohelp, tampilTanggal, tampilWaktu, gram, nomer, aktif, groupwhatsapp, youtube, host) ,MessageType.text);
}

//////////////////////////////////////////////////////////////

if (text == '!lista'){
	const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, lista.lista(id, A187, corohelp, tampilTanggal, tampilWaktu, gram, nomer, aktif, groupwhatsapp, youtube, host) ,MessageType.text);
}

///////////////////// FALAR /////////////////////


// if (text == '!map'){
	//* const teks = text.replace(/!map /, "")
//* conn.sendMessage(id, teks, 'O comando *!map*, esta em manutenção' ,MessageType.text);
// }

///////////////////// TEST ///////////////////// 



///////////////////// DIGITAR /////////////////////

if (text.includes("!folha")){
	const teks = text.replace(/!folha /, "");
  axios.get(`http://rtb-generatetext.herokuapp.com/api/joki-nulis?text=${teks}`).then ((res) => {
  imageToBase64(res.data.result.result)
        .then(
          (ress) => {
let hasil = `@space.trix`;
var buf = Buffer.from(ress, 'base64')
       conn.sendMessage(id, '✍️ Estou Escrevendo...' ,MessageType.text, { quoted: m })
       conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
       })
       })
}

///////////////////// MEME A /////////////////////

if (text.includes("!ameme")){
	const teks = text.replace(/!ameme /, "");
  axios.get(`http://rtb-generatetext.herokuapp.com/api/meme-maker?url=linkImage&text=${teks}`).then ((res) => {
  imageToBase64(res.data.result.result)
        .then(
          (ress) => {
let hasil = `@space.trix`;
var buf = Buffer.from(ress, 'base64')
       conn.sendMessage(id, '🤖 Exemplo para usar: !ameme Space/bot' ,MessageType.text, { quoted: m })
       conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
       })
       })
}

///////////////////// MEME B /////////////////////

if (text.includes("!bmeme")){
	const teks = text.replace(/!bmeme /, "");
  axios.get(`http://rtb-generatetext.herokuapp.com/api/img-text?text=${teks}`).then ((res) => {
  imageToBase64(res.data.result.result)
        .then(
          (ress) => {
let hasil = `@space.trix`;
var buf = Buffer.from(ress, 'base64')
       conn.sendMessage(id, '🤖 Exemplo para usar: !bmeme Space bot.' ,MessageType.text, { quoted: m })
       conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
       })
       })
}
///////////////////// BOT ///////////////////// 

 if (text == '!infor'){
 	// Name
     var a = ["Space Trixx","Crap Nause"];
     var mod = a[Math.floor(Math.random() * a.length)];
     // YouTube Vídeo
     var b = ["_CI-uFTvQnk","a6ix4CUrc24","z6z9xs0NUFc","CXjh2RjZkTQ","3QHSJoByMCU","7AldcEtmjlE","w4ggQz5KMPY","hUtdkfbwJHE"];
     var yt = b[Math.floor(Math.random() * b.length)];
     // link
 	var instagram = ["@space.trix"];
    ///////////
    var c = ["124gDpX/bot.jpg","PF87sBt/pornhub-Space-Trixx-Bot.jpg"];
    var vva = c[Math.floor(Math.random() * c.length)];
      imageToBase64('https://i.ibb.co/'+vva)
        .then(
          (ress) => {
            let hasil = `•|👤 Criador & Mod: *${mod}*
•|⭐ Instagram: *${instagram}*
•|📍 YouTube: *Space Trixx*
┗•••⟩ *youtu.be/${yt}*
•|🤖 Bot: *Space Trixx Bot*`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '📍 Infor Bot. | Tem algum presente Wallpaper, me chame ;)' , MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
})  
}

///////////////////// OTHELLO ///////////////////// 

if (text == '!othello'){
 	// Link
     var yt = ["othellovisualizer"];
     var insta = ["othello.vis"];
     var face = ["jangan.menangis.1088"];
    ///////////
    var vvb = ["TrwFHP9/20201219-132358.png"];
      imageToBase64('https://i.ibb.co/'+vvb)
        .then(
          (ress) => {
            let hasil = `•|📍 *Youtube.com/c/${yt}*
•|⭐ *Instagram.com/${insta}*
•|💠 *Facebook.com/${face}*`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '📍 Othello...', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
})   
}
/////////
if (text == '!dreams'){
 	// Link
     var a = ["youtube.com/c/othellovisualizer","instagram.com/othello.vis","facebook.com/jangan.menangis.1088"];
     var link = a[Math.floor(Math.random() * a.length)];
     var b = ["Andre","Othello","Trap Dreams"];
     var dono = b[Math.floor(Math.random() * b.length)];
    ///////////
    var vvc = ["KFDnns6/The-Dreams-Public-20201221-011921.jpg"];
      imageToBase64('https://i.ibb.co/'+vvc)
        .then(
          (ress) => {
            let hasil = `┝ Hi *${id.split("@s.whatsapp.net")[0]}*
├─────────────────
┢ 𝖂𝖆𝖑𝖑𝖕𝖆𝖕𝖊𝖗'𝖘:
┣ *artstation.com*
┣ *unsplash.com*
┣ *wallpaperscraft.com*
┣ *pexels.com*
┣ *pngtree.com*
┡ *pixiv.net*
├─────────────────
┢ 𝕾𝖔𝖚𝖓𝖉:
┣ *ytmp3eu.eu*
┡ *scmp3.io*
├─────────────────
┝ 𝖁𝖎𝖉𝖊𝖔: *savefrom.net*
├─────────────────
┢ 𝕲𝖎𝖋:
┣ *giphy.com*
┡ *xnxx.com*
├─────────────────
┝ 𝕱𝖔𝖓𝖙: *dafont.com*
├─────────────────
┝ 𝕽𝖚𝖑𝖊𝖘: *No Porn*
├─────────────────
┢ 𝕷𝖎𝖓𝖐 𝕲𝖗𝖔𝖚𝖕:
┣ 𝕺𝖜𝖓𝖊𝖗: *${dono}*
┣ 𝕱𝖔𝖑𝖑𝖔𝖜: *${link}*
┣ 𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕: *bit.ly/DreamsTeam*
┡ 𝕿𝖊𝖑𝖊𝖌𝖗𝖆𝖒: *t.me/songdownloader*
╰────────◇────────╯`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, "📍 The Dreams Public...", MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m });
})   
}

///////////////////// PORN RANDOM ///////////////////// 

if (text.includes("!rand")){
        var n = ["randomp"];
        var xx =  n[Math.floor(Math.random() * n.length)];
          var a = "https://xptnbotapi.herokuapp.com/api/v1/"+xx;
        axios.get(a)
      .then((result) => {
        var p = JSON.parse(JSON.stringify(result.data.url));
        conn.sendMessage(id, '🔄 Gerando link...', MessageType.text, { quoted: m })
      let hasil = `👤 Seu Link: *${p}*`;
       conn.sendMessage(id, hasil, MessageType.text, { quoted: m });
  })
 }

///////////////////// at ///////////////////// 

if (text.includes("!pornhub")){
	const teks = text.replace(/!pornhub /, "")
  axios.get(`https://xptnbotapi.herokuapp.com/api/v1/ph?l=https://www.pornhub.com/view_video.php?viewkey=${teks}`).then ((res) =>{
  conn.sendMessage(id, 'testando...' ,MessageType.text);
let hasil = `•|🎦 PornHub;

•|🔎 Title: *${res.data.title}*
•|📍 Pornstars: *${res.data.result.pornstars}*
•|📥 Download: ${res.data.download_urls}`;
       conn.sendMessage(id, hasil, MessageType.text)
    })
}

//////////////////// TC ///////////////////////
      



        
/////////////////////AMONG US /////////////////////

if (text.includes("!among")) {
	const expulso = text.replace(/!among /, "");
	var frase = ["era impostor(a)","não era impostor(a)..."];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	 	let hasil = `⠀               ⣠⣴⣶⣿⠿⢿⣶⣶⣦⣄⠀⠀       
⠀⠀⠀⠀⠀⣼⡿⠋⠁⠀⠀⠀⢀⣈⠙⢿⣷⡄⠀⠀
⠀⠀⠀⠀⢸⣿⠁⠀⢀⣴⣿⠿⠿⠿⠿⠿⢿⣷⣄⠀
⠀⢀⣀⣠⣾⣿⡇⠀⣾⣿⡄⠀⠀⠀⠀⠀⠀⠀⠹⣧
⣾⡿⠉⠉⣿⠀⡇⠀⠸⣿⡌⠓⠶⠤⣤⡤⠶⢚⣻⡟
⣿⣧⠖⠒⣿⡄⡇⠀⠀⠙⢿⣷⣶⣶⣶⣶⣶⢿⣿⠀
⣿⡇⠀⠀⣿⡇⢰⠀⠀⠀⠀⠈⠉⠉⠉⠁⠀⠀⣿⠀
⣿⡇⠀⠀⣿⡇⠈⡄⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⠀
⣿⣷⠀⠀⣿⡇⠀⠘⠦⣄⣀⣀⣀⣀⣀⡤⠊⠀⣿⠀
⢿⣿⣤⣀⣿⡇⠀⠀⠀⢀⣀⣉⡉⠁⣀⡀⠀⣾⡟⠀
⠀⠉⠛⠛⣿⡇⠀⠀⠀⠀⣿⡟⣿⡟⠋⠀⢰⣿⠃⠀
⠀⠀⠀⠀⣿⣧⠀⠀⠀⢀⣿⠃⣿⣇⠀⢀⣸⡯⠀⠀
⠀⠀⠀⠀⠹⢿⣶⣶⣶⠿⠃⠀⠈⠛⠛⠛⠛⠁⠀
*${expulso}* *${fala}*`;
	conn.sendMessage(id, hasil ,MessageType.text);
}

/////////////////////AMONG US 2 /////////////////////

if (text.includes("!us")) {
	const expulso = text.replace(/!us /, "");
	var frase = ["was impostor...","was not an impostor..."];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	var fala = frase[Math.floor(Math.random() * frase.length)];
	 	let hasil = `.    ° °•    °   ⋱  •.    °   •    °
 °.   °  •   °.   ° . ༝°   ༝ •.     .
･*.  • ° . ≋  ඞ  ༝  ° .   ｡ °  .  
∵. * .    . ° · ⋰      ༝ ° • °. *
.    ° °•    °   ⋱  •.    °   •    °
*${expulso}* *${fala}*`;
	conn.sendMessage(id, hasil ,MessageType.text);
}

///////////////////// STICKER /////////////////////

   if (messageType == 'imageMessage')   {
      let caption = imageMessage.caption.toLocaleLowerCase()
      const buffer = await conn.downloadMediaMessage(m)
      if (caption == '!fig'){
         const stiker = await conn.downloadAndSaveMediaMessage(m)
         const {
            exec
         } = require("child_process");
         exec('cwebp -q 50 ' + stiker + ' -o temp/' + jam + '.webp', (error, stdout, stderr) =>
         {
            let stik = fs.readFileSync('temp/' + jam + '.webp')
            conn.sendMessage(id, stik, MessageType.sticker)
         });
      }
   }
    
////////////////////////// COVID //////////////////////////
    
     if (text.includes("!covid")){
const teks = text.replace(/!covid /, "")
axios.get(`https://arugaz.herokuapp.com/api/corona?country=${teks}`).then((res) => {
	conn.sendMessage(id, '🔎 Consultando Mapeamento...', MessageType.text, { quoted: m })
    let hasil = `•|🌐 País: *${res.data.result.country}*\n\n•|📍 Ativos: *${res.data.result.active}*\n•|🤒 Casos: *${res.data.result.casesPerOneMillion}*\n•|🤒 Crítico: *${res.data.result.critical}*\n•|😵 Mortes: *${res.data.result.deathsPerOneMillion}*\n•|😷 Recuperados: ${res.data.result.recovered}\n•|📈 Teste por Milhão: *${res.data.result.testPerOneMillion}*\n•|📉 Hoje Caso: *${res.data.result.todayCases}*\n•|📈 Total de Morte: *${res.data.result.todayDeath}*\n•|📊 Total de Casos: *${res.data.result.totalCases}*\n•|📊 Total de Teste: *${res.data.result.totalTest}*`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
    
///////////////////// IP /////////////////////

if (text.includes("!ip")){
  const teks = text.replace(/!ip /, "") 
  axios.get(`https://mnazria.herokuapp.com/api/check?ip=${teks}`).then((res) => {
  
  let hasil = `•|📡Cidade: *${res.data.city}*\n•|📡Latitude: *${res.data.latitude}*\n•|📡Longitude: *${res.data.longitude}*\n•|📡Região: *${res.data.region_name}*\n•|📡Região COD: *${res.data.region_code}*\n•|📡IP: *${res.data.ip}*\n•|📡Tipo: *${res.data.type}*\n•|📡ZIP: *${res.data.zip}*\n•|📡Geométrico: *${res.data.location.geoname_id}*\n•|📡Capital: ${res.data.location.capital}\n•|📡DDD: *${res.data.location.calling_code}*\n•|📡Bandeira do país: ${res.data.location.country_flag_emoji}`;
  
            conn.sendMessage(id, '📡 Consultando IP...', MessageType.text, { quoted: m })
            conn.sendMessage(id, hasil, MessageType.text, { quoted: m });
 })
 }

///////////////////// MAPA /////////////////////

if (text.includes('!map')){
	const mapa = text.replace(/!map /, "") 
    axios.get('https://mnazria.herokuapp.com/api/maps?search='+mapa)
    .then((res) => {
      imageToBase64(res.data.gambar)
        .then(
          (ress) => {

         conn.sendMessage(id, '🔎 Consultando Mapeamento...', MessageType.text, { quoted: m })

         
         let ka = `Sua localização em:   *${mapa}*`;
         
         var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: ka, quoted: m });
        })
        })
}     

///////////////////// ANIME /////////////////////

    if (text.includes("!anime")){
    	var a = text.replace(/!anime /, '')
        var url = "https://api.fdci.se/rep.php?gambar="+a;
    
    conn.sendMessage(id, 'Calma ai amigo! Estou procurando o seu Anime...', MessageType.text, { quoted: m })
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	    var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(id, buf, MessageType.image, { quoted: m })
})
        .catch(
            (error) => {
                console.log(error);
            })
    });
    }

///////////////////// MEME /////////////////////

   if (text.includes("!me"))  {
    var meme = text.replace(/!me /, '')
    var url = "https://api.fdci.se/rep.php?gambar="+meme;
    
    conn.sendMessage(id, 'Calma ai amigo!, Estou procurando um meme...', MessageType.text, { quoted: m })
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(id, buf, MessageType.image, { quoted: m })
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
    
///////////////////// FACEBOOK /////////////////////

    if (text.includes("!fb")){
const teks = text.replace(/!fb /, "")
axios.get(`https://arugaz.herokuapp.com/api/fb?url=${teks}`).then((res) => {
	conn.sendMessage(id, 'Calma ai amigo!, Estou preparando o seu link', MessageType.text, { quoted: m })
    let hasil = `•|☑️ Link Sem Virus \n\n •|📽️ Revolução *SD*: ${res.data.result.sd}\n\n•|📽️ Revolução *HD*: ${res.data.result.hd}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m});
})
}
///////////////////// LETRA MÚSICA //////////////////////
 
if (text.includes("!lyrics")){
	const teks = text.split("!lyrics")[1]
	axios.get(`http://scrap.terhambar.com/lirik?word=${teks}`).then ((res) => {
	     conn.sendMessage(id, 'Calma ai amigo!, sempre estou com alguns probleminhas😅', MessageType.text, { quoted: m })
	 	let hasil = `🔎 Pesquisou: ${teks}\n\n🎶Letra:\n${res.data.result.lirik}`
	conn.sendMessage(id, hasil , MessageType.text, { quoted: m })
	})
}

///////////////////// CRYPTO CONVERT //////////////////////

if (text.includes("!curr")){
	const teks = text.replace(/!curr /, "")
	
	axios.get(`https://api.terhambar.com/currency?curr=${teks}`).then ((res) => {
		
	     conn.sendMessage(id, 'Calma ai amigo!, sempre estou com alguns probleminhas😅', MessageType.text)
	
	 	let hasil = `•|💹 Moeda: ${res.data.result.currency}*\n•|💱 Converte: *${res.data.result.convertTo}*\n•|💹 Balança: *${res.data.result.balanceCurrency}*\n\n•|💲 Resultado: *${res.data.result.resultConvert}*`
	conn.sendMessage(id, hasil, MessageType.text)
	})
}

///////////////////// CONVERTER /////////////////////

if (text.includes("!letra")){
	const alay = text.split("!letra")[1]
	axios.get(`https://api.terhambar.com/bpk?kata=${alay}`).then ((res) =>{ 
let hasil = `${res.data.text}`
		conn.sendMessage(id, hasil, MessageType.text)
	})

}
})

//*. Modificado Por:                Space Trixx
//*. Resultado Final:                22/12/2020
//*. Dono do Script:                  Tergantung kuota
//*. Diz a lenda:                         Conhecimento Não e Crime.